
// credentials
var apiKey = '45828062';
var sessionId = '2_MX40NTgyODA2Mn5-MTU3NTQwMTk4Mjg1MX5EQXBtMEc0L1VoWHAzWUtKWWVhV2g4VWF-UH4';
var token = 'T1==cGFydG5lcl9pZD00NTgyODA2MiZzaWc9NzkxZTVmMmUzOGUxMTllMzJkYzM0MTI0YWIwZjQyNjhiMGYzZmMzYTpzZXNzaW9uX2lkPTJfTVg0ME5UZ3lPREEyTW41LU1UVTNOVFF3TVRrNE1qZzFNWDVFUVhCdE1FYzBMMVZvV0hBeldVdEtXV1ZoVjJnNFZXRi1VSDQmY3JlYXRlX3RpbWU9MTU3NTQwMTk4NCZub25jZT0wLjA5OTA4MTUzMzU1ODE2OTg0JnJvbGU9cHVibGlzaGVyJmV4cGlyZV90aW1lPTE1NzU0ODgzODQ=';
const streams = [];
var streamCounter = 0;
initializeSession();

function handleError(error) {
  if (error) {
    alert(error.message);
  }
}
 var session = OT.initSession(apiKey, sessionId);
function initializeSession() {
  var session = OT.initSession(apiKey, sessionId);

  // Subscribe to a newly created stream
	session.on('streamCreated', function(event) {
		console.log(event.stream);
		streams.push(event.stream);
		console.log(streams);
		$('.publisher_list_container').append(`<li><button class="stream" data-stream-index="${streamCounter}"> Emergency - Ikoyi  <i class="fa fa-envelope"></i> </button> </li>`);
		streamCounter++;
	  
	});

  // Create a publisher
  var publisher = OT.initPublisher('publisher', {
    insertMode: 'append',
    width: '100%',
    height: '100%'
  }, handleError);

  // Connect to the session
  session.connect(token, function(error) {
    // If the connection is successful, publish to the session
    if (error) {
      handleError(error);
    } else {
      session.publish(publisher, handleError);
    }
  });
  
}

$(document).on('click','.stream',function(event){
	session.subscribe(streams[event.target.getAttribute('data-stream-index')], 'subscriber', {
		insertMode: 'append',
		width: '100%',
		height: '100%'
	  }, handleError);
});





/*// connect to session
var session = OT.initSession(apiKey, sessionId);

// create publisher
var publisher = OT.initPublisher();
session.connect(token, function(err) {
   // publish publisher
   session.publish(publisher);
}); */

  
// create subscriber
/*session.on('streamCreated', function(event) {
   session.subscribe(event.stream);
});*/
