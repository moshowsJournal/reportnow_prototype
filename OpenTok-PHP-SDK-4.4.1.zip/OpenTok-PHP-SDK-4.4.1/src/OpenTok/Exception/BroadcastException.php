<?php

namespace OpenTok\Exception;

/**
* The interface used by all exceptions resulting from calls to the broadcast API.
*/
interface BroadcastException
{
}
/* vim: set ts=4 sw=4 tw=100 sts=4 et :*/
